package com.muhammadfurqon.made_sub2.fragment;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.muhammadfurqon.made_sub2.R;
import com.muhammadfurqon.made_sub2.model.Tv;
import com.muhammadfurqon.made_sub2.model.TvAdapter;
import com.muhammadfurqon.made_sub2.presenter.CollectionInterfaceTv;
import com.muhammadfurqon.made_sub2.ui.detail.DetailTv;

import java.util.ArrayList;

public class TvFragment extends Fragment implements CollectionInterfaceTv {
    //Deklarasi Variable
    private TypedArray dataImg;
    private String[] dataNama;
    private String[] dataDesc;
    //Inisialisasi data yang akan digunakan
    private ArrayList<Tv> ntv;
    private TvAdapter adapter;
    //deklarasi variabel reyclerview
    private RecyclerView mRecyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_tv, container, false);
        prepare();
        addItem();
        mRecyclerView = rootView.findViewById(R.id.n_tv);
        adapter = new TvAdapter(ntv, getActivity(), this);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setHasFixedSize(true);

        return rootView;
    }

    private void addItem() {
        ntv = new ArrayList<>();

        for (int i = 0; i < dataNama.length; i++) {
            Tv tv = new Tv();
            tv.setImg(dataImg.getResourceId(i, -1));
            tv.setNama(dataNama[i]);
            tv.setDesc(dataDesc[i]);
            ntv.add(tv);
        }
    }


    private void prepare() {
        dataImg = getResources().obtainTypedArray(R.array.data_phototv);
        dataNama = getResources().getStringArray(R.array.data_nametv);
        dataDesc = getResources().getStringArray(R.array.data_descriptiontv);
    }

    //intent dengan interface
    @Override
    public void intentToDetail(Tv tv) {
        Intent intent = new Intent(getActivity(), DetailTv.class);
        intent.putExtra("model", tv);
        startActivity(intent);
    }

    public interface OnFragmentInteractionListener {
    }
}