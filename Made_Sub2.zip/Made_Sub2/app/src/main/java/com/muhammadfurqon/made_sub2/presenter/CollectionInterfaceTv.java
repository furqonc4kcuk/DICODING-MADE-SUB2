package com.muhammadfurqon.made_sub2.presenter;

import com.muhammadfurqon.made_sub2.model.Tv;

public interface CollectionInterfaceTv {
    void intentToDetail(Tv tv);
}
