package com.muhammadfurqon.made_sub2.fragment;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.muhammadfurqon.made_sub2.R;
import com.muhammadfurqon.made_sub2.model.AdapterMovie;
import com.muhammadfurqon.made_sub2.model.Movie;
import com.muhammadfurqon.made_sub2.presenter.CollectionInterfaceMovie;
import com.muhammadfurqon.made_sub2.ui.detail.DetailMovie;

import java.util.ArrayList;

public class MovieFragment extends Fragment implements CollectionInterfaceMovie {
    //Deklarasi Variable
    private TypedArray dataGambar;
    private String[] dataJudul;
    private String[] dataDeskripsi;
    private String[] dataTanggal;
    private String[] dataGenre;
    //Inisialisasi data yang akan digunakan
    private ArrayList<Movie> nmovie;
    private AdapterMovie adapter;
    //deklarasi variabel reyclerview
    private RecyclerView mRecyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_movie, container, false);
        prepare();
        addItem();
        //menampilkan reyclerview yang ada pada file layout dengan id n_movie
        mRecyclerView = rootView.findViewById(R.id.n_movie);
        adapter = new AdapterMovie(nmovie, getActivity(), this);
        //menset setukuran
        //menset layoutmanager dan menampilkan daftar/list
        //dalam bentuk linearlayoutmanager pada class saat ini
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));
        //membuat adapter baru untuk reyclerview
        mRecyclerView.setAdapter(adapter);
        //menset nilai dari adapter
        mRecyclerView.setHasFixedSize(true);

        return rootView;
    }

    private void addItem() {
        //Inisialisasi ArrayList
        nmovie = new ArrayList<>();

        for (int i = 0; i < dataJudul.length; i++) {
            Movie movie = new Movie();
            movie.setPhoto(dataGambar.getResourceId(i, -1));
            movie.setName(dataJudul[i]);
            movie.setDescription(dataDeskripsi[i]);
            movie.setRelease_date(dataTanggal[i]);
            movie.setGenre(dataGenre[i]);
            nmovie.add(movie);
        }
    }


    private void prepare() {
        //Ambil data picture dari array data gambar di Strings
        dataGambar = getResources().obtainTypedArray(R.array.data_photo);
        //Ambil data text dari array di Strings
        dataJudul = getResources().getStringArray(R.array.data_name);
        dataDeskripsi = getResources().getStringArray(R.array.data_description);
        dataTanggal = getResources().getStringArray(R.array.data_releasedate);
        dataGenre = getResources().getStringArray(R.array.data_genre);
    }

    //intent dengan interface
    @Override
    public void intentToDetail(Movie movie) {
        Intent intent = new Intent(getActivity(), DetailMovie.class);
        intent.putExtra("model", movie);
        startActivity(intent);
    }

    public interface OnFragmentInteractionListener {
    }
}
