package com.muhammadfurqon.made_sub2.ui.detail;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.muhammadfurqon.made_sub2.R;
import com.muhammadfurqon.made_sub2.model.Tv;
import com.squareup.picasso.Picasso;

public class DetailTv  extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tv_detail);

        //get data Movie send by MainActivity with EXTRA_MOVIE
        Tv selectedMovie = getIntent().getParcelableExtra("model");

        if (selectedMovie != null) {
            ImageView imgFoto = findViewById(R.id.iv_detail_photo);
            Picasso.get().load(selectedMovie.getImg()).fit().centerCrop().into(imgFoto);

            TextView txtNama = findViewById(R.id.tv_detail_name);
            txtNama.setText(selectedMovie.getNama());

            TextView txtDesc = findViewById(R.id.tv_detail_description);
            txtDesc.setText(selectedMovie.getDesc());
        }
        setActionBarTitle("TV CATALOGUE");
    }

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }
}