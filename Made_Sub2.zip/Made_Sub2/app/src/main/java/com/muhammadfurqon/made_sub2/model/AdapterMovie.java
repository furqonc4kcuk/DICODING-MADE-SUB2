package com.muhammadfurqon.made_sub2.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.muhammadfurqon.made_sub2.R;
import com.muhammadfurqon.made_sub2.fragment.MovieFragment;
import com.muhammadfurqon.made_sub2.model.Movie;
import com.muhammadfurqon.made_sub2.presenter.CollectionInterfaceMovie;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterMovie extends RecyclerView.Adapter<AdapterMovie.ViewHolder> {
    private ArrayList<Movie> list;
    private Context context;
    private View.OnClickListener listener;
    private View view;
    private CollectionInterfaceMovie collectionInterfaceMovie;


    public AdapterMovie(ArrayList<Movie> list, Context context, CollectionInterfaceMovie collectionInterfaceMovie) {
        this.list = list;
        this.context = context;
        this.collectionInterfaceMovie = collectionInterfaceMovie;
    }

    @NonNull
    @Override
    public AdapterMovie.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_movie, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMovie.ViewHolder holder, int position) {
        holder.tvJudul.setText(list.get(position).getName());
        holder.ivGambar.setImageResource(list.get(position).getPhoto());
        holder.tvDeskripsi.setText(list.get(position).getDescription());
        holder.tvGenre.setText(list.get(position).getGenre());
        holder.tvTanggalRilis.setText(list.get(position).getRelease_date());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul;
        ImageView ivGambar;
        TextView tvDeskripsi;
        TextView tvGenre;
        TextView tvTanggalRilis;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            tvJudul = itemView.findViewById(R.id.tv_title);
            ivGambar = itemView.findViewById(R.id.iv_image);
            tvTanggalRilis = itemView.findViewById(R.id.tv_release_date);
            tvGenre = itemView.findViewById(R.id.tv_genre);
            tvDeskripsi = itemView.findViewById(R.id.tv_description);
            //onclick
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    collectionInterfaceMovie.intentToDetail(list.get(getAdapterPosition()));
                }
            });
        }
    }
}