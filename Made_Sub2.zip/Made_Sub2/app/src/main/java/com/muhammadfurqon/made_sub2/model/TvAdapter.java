package com.muhammadfurqon.made_sub2.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.muhammadfurqon.made_sub2.R;
import com.muhammadfurqon.made_sub2.fragment.TvFragment;
import com.muhammadfurqon.made_sub2.presenter.CollectionInterfaceTv;

import java.util.ArrayList;

public class TvAdapter extends RecyclerView.Adapter<TvAdapter.ViewHolder> {
private ArrayList<Tv> list;
private Context context;
private View.OnClickListener listener;
private View view;
private CollectionInterfaceTv collectionInterfaceTv;


public TvAdapter(ArrayList<Tv> list, Context context, TvFragment collectionInterfaceTv) {
        this.list = list;
        this.context = context;
        this.collectionInterfaceTv = (CollectionInterfaceTv) collectionInterfaceTv;
        }

@NonNull
@Override
public TvAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_tv, parent, false);
        return new ViewHolder(view);
        }

@Override
public void onBindViewHolder(@NonNull TvAdapter.ViewHolder holder, int position) {
        holder.tvNama.setText(list.get(position).getNama());
        holder.tvDesc.setText(list.get(position).getDesc());
        holder.ivImg.setImageResource(list.get(position).getImg());


        }

@Override
public int getItemCount() {
        return list.size();
        }

public class ViewHolder extends RecyclerView.ViewHolder {
    TextView tvNama;
    ImageView ivImg;
    TextView tvDesc;

    public ViewHolder(@NonNull final View itemView) {
        super(itemView);

        tvNama = itemView.findViewById(R.id.tv_name);
        ivImg = itemView.findViewById(R.id.iv_img);
        tvDesc = itemView.findViewById(R.id.tv_desc);
        //onclick
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                collectionInterfaceTv.intentToDetail(list.get(getAdapterPosition()));
            }
        });
    }
}
}