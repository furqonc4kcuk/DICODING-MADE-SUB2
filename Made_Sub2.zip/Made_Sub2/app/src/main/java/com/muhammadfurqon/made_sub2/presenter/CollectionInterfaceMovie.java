package com.muhammadfurqon.made_sub2.presenter;

import com.muhammadfurqon.made_sub2.model.Movie;

public interface CollectionInterfaceMovie {
    void intentToDetail(Movie movie);
}
